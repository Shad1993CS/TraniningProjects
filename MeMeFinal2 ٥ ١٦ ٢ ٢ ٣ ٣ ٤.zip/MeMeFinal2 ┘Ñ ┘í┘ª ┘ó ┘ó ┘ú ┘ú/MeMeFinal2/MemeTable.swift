//
//  MemeTable.swift
//  MeMeFinal2
//
//  Created by Shahed Al-shanbati on ٣ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

class MemeTable: UIViewController , UITableViewDelegate,UITableViewDataSource {
    
    
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    
    @IBOutlet weak var tableV: UITableView!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableV.reloadData()
        self.tabBarController?.tabBar.isHidden = false
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Table") as! tableViewCellTableViewCell
        let meme = self.memes[(indexPath as NSIndexPath).row]
        cell.tableLable.text = meme.topText
        cell.tableImage.image = meme.memedImage
        
        if let detailTextLabel = cell.detailTextLabel {
            detailTextLabel.text = "bottonText \(meme.bottomText)"
        }
        
        return cell
    }
    

  
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "Detail") as!
            DetailViewController
        detailController.detail = self.memes[(indexPath as NSIndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
       
        
        
    }
    
    
    @IBAction func editMeme(_ sender: Any) {
        performSegue(withIdentifier: "SegueT", sender: self)
    }
    
    

}
