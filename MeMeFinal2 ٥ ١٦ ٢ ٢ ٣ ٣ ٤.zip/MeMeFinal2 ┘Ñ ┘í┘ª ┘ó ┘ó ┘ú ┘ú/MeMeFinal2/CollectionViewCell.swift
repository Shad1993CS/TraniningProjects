//
//  CollectionViewCell.swift
//  MeMeFinal2
//
//  Created by Shahed Al-shanbati on ٣ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var clellLable: UILabel!
    @IBOutlet weak var celImage: UIImageView!
    
}
