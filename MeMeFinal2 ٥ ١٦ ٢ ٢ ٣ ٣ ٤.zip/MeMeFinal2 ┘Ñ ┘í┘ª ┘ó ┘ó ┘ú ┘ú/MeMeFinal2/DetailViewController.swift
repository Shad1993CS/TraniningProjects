//
//  DetailViewController.swift
//  MeMeFinal2
//
//  Created by Shahed Al-shanbati on ٣ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    var detail : Meme!
    
    
    @IBOutlet weak var deitalImage: UIImageView!
    @IBOutlet weak var detailLable: UILabel!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.detailLable.text = self.detail.topText
        self.tabBarController?.tabBar.isHidden = true
        self.deitalImage.image = self.detail.memedImage
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    
    
    
    
    
    



}
