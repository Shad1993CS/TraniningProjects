//
//  ViewController.swift
//  MeMeFinal2
//
//  Created by Shahed Al-shanbati on ٧ ربيع١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

struct Meme{
    
    var topText:String
    var bottomText:String
    var oreginalImage:UIImage!
    var memedImage : UIImage!
}




class ViewController: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate{
    @IBOutlet weak var pickImageView: UIImageView?
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    @IBOutlet weak var topTextFild: UITextField!
    
    @IBOutlet weak var bottomTextFild: UITextField!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setText(textField: topTextFild, string: "TOP")
        setText(textField: bottomTextFild, string: "BOTTOM")
        shareButton.isEnabled = false
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func picAnImageFromAlbum(_ sender: Any) {
        
         presentImagePickerWith(sourceType: .photoLibrary)
        
    }
    
    
    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        
        presentImagePickerWith(sourceType: .camera)
        
    }
    
    
    func presentImagePickerWith(sourceType: UIImagePickerControllerSourceType) {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = sourceType
        present(pickerController, animated:true, completion:nil)
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
      subScribeToKeyboardNotification()
        subScribeTokeyboardHideNotification()
        
        
        if (pickImageView?.image) != nil{
          shareButton.isEnabled = true
        }else{
            
            shareButton.isEnabled = false
        }
            
            
        }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unSubscribeFromKeyboardNotification()
        unSubscribeFromHideKeyboardNotification()
      
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            pickImageView?.contentMode = .scaleAspectFit
            pickImageView?.image = image
            
        }
    dismiss(animated: true, completion: nil)
        
    }
    
    
    private func textFieldShouldBeginEditing(_ textField: UITextField){
        if textField.text == "TOP " || textField.text == "BOTTOM" {
            textField.text = ""
            
        }

        }
    
        
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            
            return true;
        }
    
    @objc func keyboardWillShow(_ notification:Notification){
        if (bottomTextFild.isFirstResponder){
            view.frame.origin.y = -getKeyboardHeight(notification)
            
        }
        
    }
    
    func subScribeToKeyboardNotification(){
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name:.UIKeyboardWillShow, object: nil)
        unSubscribeFromHideKeyboardNotification()
        
    }
    
   
    
    func  getKeyboardHeight(_ notification:Notification) -> CGFloat{
       let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
        
    }
    
    func unSubscribeFromKeyboardNotification(){
        
     NotificationCenter.default.removeObserver(self, name:.UIKeyboardWillShow, object: nil)
        subScribeTokeyboardHideNotification()
        
    }
    
    
    @objc func keybaordWillHide(_ notification:Notification){
        
        view.frame.origin.y = 0
         unSubscribeFromHideKeyboardNotification()
        
    }
    
    func subScribeTokeyboardHideNotification(){
        NotificationCenter.default.addObserver(self, selector: #selector(keybaordWillHide(_:)), name:.UIKeyboardWillHide, object: nil)
       
    }
    func unSubscribeFromHideKeyboardNotification(){
         NotificationCenter.default.removeObserver(self, name:.UIKeyboardWillHide, object: nil)
    }
    
    
  
    
    func save() {
        // Create the meme
        let meme1:UIImage = generateMemedImage() 
        let meme2 = Meme(topText: topTextFild.text!, bottomText: bottomTextFild.text!, oreginalImage: pickImageView?.image!, memedImage: meme1)
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme2)
        
        
    }
    
  
    
   func generateMemedImage() -> UIImage {
        
    
         navigationController?.setToolbarHidden(true, animated: false)
    
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
    navigationController?.setToolbarHidden(false, animated: false)
        
        return memedImage
  }
    
    @IBAction func shareButtonImplemnt(_ sender: Any) {
        
        if shareButton.isEnabled{
            let memedImages:UIImage = generateMemedImage()
            _ = UIActivityViewController(activityItems: [memedImages], applicationActivities: nil)
          
            if shareButton.isEnabled{
                let memedImages:UIImage = generateMemedImage()
                let controller = UIActivityViewController(activityItems: [memedImages], applicationActivities: nil)
                
                controller.completionWithItemsHandler = {(activityType: UIActivityType?, completed: Bool, returnedItems: [Any]?, error: Error?) in
                    if (completed) {
                        self.save()
                        self.dismiss(animated: true, completion: nil)
                }
               
            }
         self.present(controller, animated: true, completion: nil)
    }
    }
    }
    
    func setText(textField: UITextField, string: String){
        textField.text = string
        textField.defaultTextAttributes = memeMeTextAttributes
        textField.textAlignment = .center
        textField.delegate = self
        textField.borderStyle = .none
    }
    
    let memeMeTextAttributes:[String:Any] = [
        NSAttributedStringKey.strokeColor.rawValue: UIColor.black ,
        NSAttributedStringKey.foregroundColor.rawValue: UIColor.white,
        NSAttributedStringKey.font.rawValue: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedStringKey.strokeWidth.rawValue: -3.0
    ]
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    @IBAction func cancelButton(_ sender: Any) {
        
        performSegue(withIdentifier: "SegueCA", sender: self)
    }
    
    

    

}
