//
//  tableViewCellTableViewCell.swift
//  MeMeFinal2
//
//  Created by Shahed Al-shanbati on ٥ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

class tableViewCellTableViewCell: UITableViewCell {

 
    @IBOutlet weak var tableImage: UIImageView!
    @IBOutlet weak var tableLable: UILabel!
    
    
    
    

}
